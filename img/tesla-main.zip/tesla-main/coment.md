<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Swiper demo</title>
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1"
    />
   

    <!-- Demo styles -->
  
    </style>
  </head>

  <body>
    <!-- Swiper -->
    

    <!-- Swiper JS -->
    

    <!-- Initialize Swiper -->
    <script>
     
    </script>
  </body>
</html>
